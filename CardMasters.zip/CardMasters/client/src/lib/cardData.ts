import { Card } from '@/types/card';

const cardNames = [
  'Fire Dragon', 'Ice Phoenix', 'Lightning Tiger', 'Earth Golem', 'Wind Eagle',
  'Shadow Wolf', 'Light Angel', 'Water Serpent', 'Stone Giant', 'Flame Warrior',
  'Frost Mage', 'Thunder Knight', 'Nature Spirit', 'Dark Assassin', 'Holy Paladin',
  'Storm Elemental', 'Crystal Guardian', 'Void Hunter', 'Solar Priest', 'Lunar Archer',
  'Nebula Wraith', 'Obsidian Ravager', 'Echo Seraph', 'Ironclad Behemoth', 'Venomous Hydra',
  'Radiant Valkyrie', 'Tempest Howler', 'Silver Chimera', 'Blight Reaper', 'Arcane Trickster',
  'Celestial Drake', 'Dusk Stalker', 'Inferno Djinn', 'Glacial Sentinel', 'Twilight Lancer',
  'Phantom Corsair', 'Bloodthorn Viper', 'Ethereal Mystic', 'Stormbreaker Titan', 'Gilded Scorpion'
];

const moves = [
  'Strike', 'Slash', 'Smash', 'Bite', 'Claw', 'Stomp', 'Charge', 'Leap',
  'Fireball', 'Ice Shard', 'Lightning Bolt', 'Rock Throw', 'Wind Blade',
  'Shadow Strike', 'Light Beam', 'Water Jet', 'Earthquake', 'Explosion',
  'Heal', 'Shield', 'Boost', 'Curse', 'Blessing', 'Teleport',
  'Venom Spit', 'Phantom Slash', 'Meteor Crash', 'Blazing Arrow', 'Frost Nova',
  'Thunder Clap', 'Sandstorm', 'Soul Drain', 'Dark Pulse', 'Radiant Flash',
  'Spirit Bind', 'Ice Fang', 'Flame Whip', 'Arcane Blast', 'Poison Cloud',
  'Shadow Step', 'Light Spear', 'Gravity Crush', 'Blood Siphon', 'Wind Surge'
];

const aceAbilities = [
  'Berserker Rage', 'Ice Armor', 'Lightning Speed', 'Stone Skin', 'Flight',
  'Stealth', 'Divine Protection', 'Tidal Wave', 'Mountain Fortress', 'Phoenix Rebirth',
  'Shadow Veil', 'Celestial Fury', 'Void Shift', 'Temporal Freeze', 'Thunder Roar',
  'Blazing Aegis', 'Soul Echo', 'Arcane Veins', 'Iron Will', 'Spirit Surge',
  'Frostbite Aura', 'Venomous Grasp', 'Solar Flare', 'Wind Cloak', 'Blood Pact',
  'Ethereal Chains', 'Stonewall Guard', 'Phantom Mirage', 'Gravity Well', 'Radiant Halo'
];


function getRandomElement<T>(array: T[]): T {
  return array[Math.floor(Math.random() * array.length)];
}

export type PackType = 
  | 'common' 
  | 'rare' 
  | 'epic' 
  | 'legendary' 
  | 'mythic' 
  | 'forsaken';

interface PackConfig {
  price: number;
  rarityChances: {
    common: number;
    rare: number;
    epic: number;
    legendary: number;
    mythic: number;
    forsaken: number;
  };
  guaranteedCards: {
    common: number;
    rareOrBetter: number;
    random: number;
  };
}

export const PACK_CONFIGS: Record<PackType, PackConfig> = {
  common: {
    price: 100,
    rarityChances: {
      common: 0.8,
      rare: 0.15,
      epic: 0.04,
      legendary: 0.009,
      mythic: 0.0009,
      forsaken: 0.0001,
    },
    guaranteedCards: {
      common: 3,
      rareOrBetter: 1,
      random: 1,
    },
  },
  rare: {
    price: 250,
    rarityChances: {
      common: 0.6,
      rare: 0.25,
      epic: 0.1,
      legendary: 0.04,
      mythic: 0.009,
      forsaken: 0.001,
    },
    guaranteedCards: {
      common: 2,
      rareOrBetter: 2,
      random: 1,
    },
  },
  epic: {
    price: 500,
    rarityChances: {
      common: 0.4,
      rare: 0.3,
      epic: 0.2,
      legendary: 0.07,
      mythic: 0.02,
      forsaken: 0.01,
    },
    guaranteedCards: {
      common: 1,
      rareOrBetter: 2,
      random: 2,
    },
  },
  legendary: {
    price: 1000,
    rarityChances: {
      common: 0.25,
      rare: 0.25,
      epic: 0.3,
      legendary: 0.15,
      mythic: 0.04,
      forsaken: 0.01,
    },
    guaranteedCards: {
      common: 0,
      rareOrBetter: 3,
      random: 2,
    },
  },
  mythic: {
    price: 2000,
    rarityChances: {
      common: 0.1,
      rare: 0.2,
      epic: 0.3,
      legendary: 0.25,
      mythic: 0.1,
      forsaken: 0.05,
    },
    guaranteedCards: {
      common: 0,
      rareOrBetter: 4,
      random: 1,
    },
  },
  forsaken: {
    price: 5000,
    rarityChances: {
      common: 0,
      rare: 0.1,
      epic: 0.2,
      legendary: 0.3,
      mythic: 0.3,
      forsaken: 0.1,
    },
    guaranteedCards: {
      common: 0,
      rareOrBetter: 5,
      random: 0,
    },
  },
};

function selectRarity(chances: PackConfig['rarityChances']): string {
  const rand = Math.random();
  let cumulative = 0;

  for (const rarity of ['common', 'rare', 'epic', 'legendary', 'mythic', 'forsaken'] as const) {
    cumulative += chances[rarity];
    if (rand < cumulative) return rarity;
  }
  return 'common'; // fallback
}

export function generateRandomCards(customRarityChances?: PackConfig['rarityChances']): Card {
  const defaultChances = PACK_CONFIGS.common.rarityChances;

  const chances = customRarityChances || defaultChances;
  const rarity = selectRarity(chances);

  const rarityMultiplier = {
    common: 1,
    rare: 1.2,
    epic: 1.5,
    legendary: 2,
    mythic: 2.5,
    forsaken: 3
  }[rarity];

  const baseHp = Math.floor((30 + Math.random() * 50) * rarityMultiplier);
  const baseMana = Math.floor((10 + Math.random() * 20) * rarityMultiplier);
  const baseSpeed = Math.floor((5 + Math.random() * 15) * rarityMultiplier);

  return {
    id: `card_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    name: getRandomElement(cardNames),
    hp: baseHp,
    mana: baseMana,
    move1: getRandomElement(moves),
    cost1: Math.floor(2 + Math.random() * 3),
    move2: getRandomElement(moves),
    cost2: Math.floor(4 + Math.random() * 4),
    move3: getRandomElement(moves),
    cost3: Math.floor(6 + Math.random() * 5),
    ace: getRandomElement(aceAbilities),
    speed: baseSpeed,
    rarity,
  };
}

export function generateCardPack(packType: PackType = 'common'): Card[] {
  const config = PACK_CONFIGS[packType];

  const pack: Card[] = [];

  // Guaranteed common cards
  for (let i = 0; i < (config.guaranteedCards.common || 0); i++) {
    const card = generateRandomCards(config.rarityChances);
    card.rarity = 'common'; // force common rarity for these guaranteed cards
    pack.push(card);
  }

  // Guaranteed rare or better cards
  for (let i = 0; i < (config.guaranteedCards.rareOrBetter || 0); i++) {
    let card: Card;
    do {
      card = generateRandomCards(config.rarityChances);
    } while (card.rarity === 'common'); // reroll if common
    pack.push(card);
  }

  // Random cards (any rarity)
  for (let i = 0; i < (config.guaranteedCards.random || 0); i++) {
    pack.push(generateRandomCards(config.rarityChances));
  }

  return pack;
}
