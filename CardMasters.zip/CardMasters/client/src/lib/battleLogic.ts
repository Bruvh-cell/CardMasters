import { PlayerCard } from '@/types/card';
import { BattleAction } from '@/types/battle';

export function getBaseDamage(moveType: 'move1' | 'move2' | 'move3' | 'ace'): number {
  return {
    move1: 15,
    move2: 25,
    move3: 35,
    ace: 50
  }[moveType];
}

export function calculateDamage(attacker: PlayerCard, target: PlayerCard, moveType: 'move1' | 'move2' | 'move3' | 'ace'): number {
  const baseDamage = getBaseDamage(moveType);
  
  // Add some randomness (±20%)
  const variance = 0.2;
  const multiplier = 1 + (Math.random() - 0.5) * variance * 2;
  
  // Factor in attacker's speed vs target's speed
  const speedDifference = Math.max(0, attacker.speed - target.speed);
  const speedBonus = speedDifference * 0.1;
  
  return Math.floor(baseDamage * multiplier * (1 + speedBonus));
}

export function getMoveCost(card: PlayerCard, moveType: 'move1' | 'move2' | 'move3' | 'ace'): number {
  return {
    move1: card.cost1,
    move2: card.cost2,
    move3: card.cost3,
    ace: Math.floor(card.mana * 0.8) // Ace costs 80% of max mana
  }[moveType];
}

export function canUseMove(card: PlayerCard, moveType: 'move1' | 'move2' | 'move3' | 'ace'): boolean {
  const cost = getMoveCost(card, moveType);
  return card.currentMana >= cost && card.currentHp > 0;
}

export function getRandomMove(card: PlayerCard): 'move1' | 'move2' | 'move3' | 'ace' | null {
  const availableMoves: ('move1' | 'move2' | 'move3' | 'ace')[] = [];
  
  if (canUseMove(card, 'move1')) availableMoves.push('move1');
  if (canUseMove(card, 'move2')) availableMoves.push('move2');
  if (canUseMove(card, 'move3')) availableMoves.push('move3');
  if (canUseMove(card, 'ace')) availableMoves.push('ace');
  
  if (availableMoves.length === 0) return null;
  
  // Weighted selection (prefer lower cost moves)
  const weights = availableMoves.map(move => {
    const cost = getMoveCost(card, move);
    return Math.max(1, 10 - cost); // Higher weight for lower cost moves
  });
  
  const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
  let random = Math.random() * totalWeight;
  
  for (let i = 0; i < availableMoves.length; i++) {
    random -= weights[i];
    if (random <= 0) {
      return availableMoves[i];
    }
  }
  
  return availableMoves[0]; // Fallback
}

export function executeMove(attacker: PlayerCard, target: PlayerCard, moveType: 'move1' | 'move2' | 'move3' | 'ace'): BattleAction {
  const damage = calculateDamage(attacker, target, moveType);
  const manaCost = getMoveCost(attacker, moveType);
  
  return {
    type: moveType,
    attacker,
    target,
    damage,
    manaCost
  };
}

export function getActiveCard(cards: PlayerCard[], activeIndex: number): PlayerCard | null {
  if (activeIndex >= 0 && activeIndex < cards.length && cards[activeIndex].currentHp > 0) {
    return cards[activeIndex];
  }
  return null;
}

export function getRandomTarget(cards: PlayerCard[], activeIndex?: number): PlayerCard | null {
  // For 1v1 mode, target the active card specifically
  if (activeIndex !== undefined) {
    return getActiveCard(cards, activeIndex);
  }
  
  // For 3v3 mode, any alive card can be targeted
  const aliveCards = cards.filter(card => card.currentHp > 0);
  if (aliveCards.length === 0) return null;
  
  return aliveCards[Math.floor(Math.random() * aliveCards.length)];
}

export function getRandomAttacker(cards: PlayerCard[], activeIndex?: number): PlayerCard | null {
  // For 1v1 mode, only the active card can attack
  if (activeIndex !== undefined) {
    return getActiveCard(cards, activeIndex);
  }
  
  // For 3v3 mode, any alive card can attack
  const aliveCards = cards.filter(card => card.currentHp > 0);
  if (aliveCards.length === 0) return null;
  
  // Prefer cards with more mana
  const weights = aliveCards.map(card => Math.max(1, card.currentMana));
  const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
  let random = Math.random() * totalWeight;
  
  for (let i = 0; i < aliveCards.length; i++) {
    random -= weights[i];
    if (random <= 0) {
      return aliveCards[i];
    }
  }
  
  return aliveCards[0]; // Fallback
}
