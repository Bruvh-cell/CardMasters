import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface PlayerState {
  coins: number;
  wins: number;
  losses: number;
  packsOpened: number;
  
  // Actions
  addCoins: (amount: number) => void;
  spendCoins: (amount: number) => boolean;
  addWin: () => void;
  addLoss: () => void;
  incrementPacksOpened: () => void;
}

export const usePlayer = create<PlayerState>()(
  persist(
    (set, get) => ({
      coins: 200, // Starting coins
      wins: 0,
      losses: 0,
      packsOpened: 0,
      
      addCoins: (amount) => set((state) => ({
        coins: state.coins + amount
      })),
      
      spendCoins: (amount) => {
        const state = get();
        if (state.coins >= amount) {
          set({ coins: state.coins - amount });
          return true;
        }
        return false;
      },
      
      addWin: () => set((state) => ({
        wins: state.wins + 1
      })),
      
      addLoss: () => set((state) => ({
        losses: state.losses + 1
      })),
      
      incrementPacksOpened: () => set((state) => ({
        packsOpened: state.packsOpened + 1
      })),
    }),
    {
      name: 'player-storage',
    }
  )
);
