import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Card } from '@/types/card';
import { generateRandomCards } from '@/lib/cardData';

interface CardsState {
  collection: Card[];
  decks: {
    '1v1': Card[];
    '3v3': Card[];
  };

  // Actions
  addCard: (card: Card) => void;
  addCards: (cards: Card[]) => void;
  addToDeck: (mode: '1v1' | '3v3', card: Card) => boolean;
  removeFromDeck: (mode: '1v1' | '3v3', cardId: string) => void;
  clearDeck: (mode: '1v1' | '3v3') => void;
  initializeStarterCards: () => void;

  // New method to remove a card from collection
  removeCard: (cardId: string) => void;
}

export const useCards = create<CardsState>()(
  persist(
    (set, get) => ({
      collection: [],
      decks: {
        '1v1': [],
        '3v3': [],
      },

      addCard: (card) =>
        set((state) => ({
          collection: [...(Array.isArray(state.collection) ? state.collection : []), card],
        })),

      addCards: (cards) =>
        set((state) => ({
          collection: [...(Array.isArray(state.collection) ? state.collection : []), ...cards],
        })),

      addToDeck: (mode, card) => {
        const state = get();
        const maxSize = mode === '1v1' ? 5 : 7;

        if (state.decks[mode].length >= maxSize) {
          return false;
        }

        if (state.decks[mode].find((c) => c.id === card.id)) {
          return false;
        }

        set((state) => ({
          decks: {
            ...state.decks,
            [mode]: [...state.decks[mode], card],
          },
        }));

        return true;
      },

      removeFromDeck: (mode, cardId) =>
        set((state) => ({
          decks: {
            ...state.decks,
            [mode]: state.decks[mode].filter((card) => card.id !== cardId),
          },
        })),

      clearDeck: (mode) =>
        set((state) => ({
          decks: {
            ...state.decks,
            [mode]: [],
          },
        })),

      initializeStarterCards: () => {
        const state = get();
        if (!Array.isArray(state.collection) || state.collection.length === 0) {
          const starterCards = generateRandomCards(10);
          set({ collection: starterCards });
        }
      },

      removeCard: (cardId) =>
        set((state) => ({
          collection: (Array.isArray(state.collection) ? state.collection : []).filter(
            (card) => card.id !== cardId
          ),
          decks: {
            '1v1': state.decks['1v1'].filter((card) => card.id !== cardId),
            '3v3': state.decks['3v3'].filter((card) => card.id !== cardId),
          },
        })),
    }),
    {
      name: 'cards-storage',
    }
  )
);
