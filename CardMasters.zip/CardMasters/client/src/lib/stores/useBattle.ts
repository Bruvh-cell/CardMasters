import { create } from 'zustand';
import { BattleState, BattleAction, BattleResult, BattleMode } from '@/types/battle';
import { PlayerCard } from '@/types/card';
import { executeMove, calculateDamage } from '@/lib/battleLogic';

interface BattleStore extends BattleState {
  // Actions
  initBattle: (mode: BattleMode, playerCards: PlayerCard[], enemyCards: PlayerCard[]) => void;
  executeAction: (action: BattleAction) => void;
  switchActiveCard: (side: 'player' | 'enemy', cardIndex: number) => void;
  endTurn: () => void;
  endBattle: (winner: 'player' | 'enemy') => BattleResult;
  resetBattle: () => void;
  addLogEntry: (entry: string) => void;
}

const initialState: BattleState = {
  mode: '1v1',
  phase: 'setup',
  playerCards: [],
  enemyCards: [],
  activePlayerCardIndex: 0,
  activeEnemyCardIndex: 0,
  currentTurn: 'player',
  turnCount: 1,
  winner: null,
  battleLog: [],
};

export const useBattle = create<BattleStore>((set, get) => ({
  ...initialState,
  
  initBattle: (mode, playerCards, enemyCards) => {
    const battleCards = playerCards.map(card => ({
      ...card,
      currentHp: card.hp,
      currentMana: card.mana
    }));
    
    const battleEnemies = enemyCards.map(card => ({
      ...card,
      currentHp: card.hp,
      currentMana: card.mana
    }));
    
    set({
      mode,
      phase: 'active',
      playerCards: battleCards,
      enemyCards: battleEnemies,
      activePlayerCardIndex: 0,
      activeEnemyCardIndex: 0,
      currentTurn: 'player',
      turnCount: 1,
      winner: null,
      battleLog: [`Battle ${mode} started!`],
    });
  },
  
  executeAction: (action) => {
    const state = get();
    if (state.phase !== 'active') return;
    
    const { attacker, target, damage, manaCost } = action;
    
    // Check if attacker has enough mana
    if (attacker.currentMana < manaCost) {
      get().addLogEntry(`${attacker.name} doesn't have enough mana!`);
      return;
    }
    
    // Deduct mana
    attacker.currentMana -= manaCost;
    
    // Apply damage
    target.currentHp = Math.max(0, target.currentHp - damage);
    
    // Get the actual move name
    const moveName = action.type === 'move1' ? attacker.move1 :
                     action.type === 'move2' ? attacker.move2 :
                     action.type === 'move3' ? attacker.move3 :
                     attacker.ace;
    
    get().addLogEntry(`${attacker.name} used ${moveName} on ${target.name} for ${damage} damage!`);
    
    // Check for defeated cards and auto-switch if needed
    if (target.currentHp <= 0) {
      get().addLogEntry(`${target.name} was defeated!`);
      
      // Auto-switch to next available card if active card was defeated
      const updatedState = get();
      const alivePlayerCards = updatedState.playerCards.filter(card => card.currentHp > 0);
      const aliveEnemyCards = updatedState.enemyCards.filter(card => card.currentHp > 0);
      
      // Check if we need to switch active cards
      if (updatedState.playerCards[updatedState.activePlayerCardIndex]?.currentHp <= 0 && alivePlayerCards.length > 0) {
        const nextPlayerCardIndex = updatedState.playerCards.findIndex(card => card.currentHp > 0);
        if (nextPlayerCardIndex !== -1) {
          set({ activePlayerCardIndex: nextPlayerCardIndex });
          get().addLogEntry(`${updatedState.playerCards[nextPlayerCardIndex].name} is automatically switched in!`);
        }
      }
      
      if (updatedState.enemyCards[updatedState.activeEnemyCardIndex]?.currentHp <= 0 && aliveEnemyCards.length > 0) {
        const nextEnemyCardIndex = updatedState.enemyCards.findIndex(card => card.currentHp > 0);
        if (nextEnemyCardIndex !== -1) {
          set({ activeEnemyCardIndex: nextEnemyCardIndex });
          get().addLogEntry(`${updatedState.enemyCards[nextEnemyCardIndex].name} is automatically switched in!`);
        }
      }
      
      // Check win conditions
      if (alivePlayerCards.length === 0) {
        set({ phase: 'ended', winner: 'enemy' });
        get().addLogEntry('Enemy wins!');
      } else if (aliveEnemyCards.length === 0) {
        set({ phase: 'ended', winner: 'player' });
        get().addLogEntry('Player wins!');
      }
    }
  },
  
  switchActiveCard: (side, cardIndex) => {
    const state = get();
    if (state.phase !== 'active') return;
    
    if (side === 'player') {
      if (cardIndex >= 0 && cardIndex < state.playerCards.length && state.playerCards[cardIndex].currentHp > 0) {
        set({ activePlayerCardIndex: cardIndex });
        get().addLogEntry(`${state.playerCards[cardIndex].name} is now the active player card!`);
      }
    } else {
      if (cardIndex >= 0 && cardIndex < state.enemyCards.length && state.enemyCards[cardIndex].currentHp > 0) {
        set({ activeEnemyCardIndex: cardIndex });
        get().addLogEntry(`${state.enemyCards[cardIndex].name} is now the active enemy card!`);
      }
    }
  },
  
  endTurn: () => {
    const state = get();
    if (state.phase !== 'active') return;
    
    // Restore mana each turn (20% of max mana, minimum 2)
    const newPlayerCards = state.playerCards.map(card => ({
      ...card,
      currentMana: Math.min(card.mana, card.currentMana + Math.max(2, Math.floor(card.mana * 0.2)))
    }));
    
    const newEnemyCards = state.enemyCards.map(card => ({
      ...card,
      currentMana: Math.min(card.mana, card.currentMana + Math.max(2, Math.floor(card.mana * 0.2)))
    }));
    
    set({
      playerCards: newPlayerCards,
      enemyCards: newEnemyCards,
      currentTurn: state.currentTurn === 'player' ? 'enemy' : 'player',
      turnCount: state.currentTurn === 'enemy' ? state.turnCount + 1 : state.turnCount,
    });
    
    get().addLogEntry(`Turn ${state.turnCount} - ${state.currentTurn === 'player' ? 'Enemy' : 'Player'}'s turn`);
    get().addLogEntry(`All cards recover ${Math.max(2, Math.floor(state.playerCards[0]?.mana * 0.2 || 2))} mana!`);
  },
  
  endBattle: (winner) => {
    const state = get();
    /*Update the card to say the new coins gained */
    const coinsEarned = winner === 'player' ? (state.mode === '1v1' ? 100 : 200) : 50;
    
    return {
      winner,
      coinsEarned,
      playerCards: state.playerCards,
      enemyCards: state.enemyCards,
    };
  },
  
  resetBattle: () => set(initialState),
  
  addLogEntry: (entry) => set((state) => ({
    battleLog: [...state.battleLog, entry]
  })),
}));
