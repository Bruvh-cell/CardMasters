import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CardDisplay } from './CardDisplay';
import { useCards } from '@/lib/stores/useCards';
import { usePlayer } from '@/lib/stores/usePlayer';
import { generateCardPack, PACK_CONFIGS, PackType } from '@/lib/cardData';
import { ArrowLeft, Package, Sparkles } from 'lucide-react';
import { Card as CardType } from '@/types/card';

interface CardPackOpeningProps {
  onBack: () => void;
}

export function CardPackOpening({ onBack }: CardPackOpeningProps) {
  const { addCards } = useCards();
  const { coins, spendCoins, incrementPacksOpened } = usePlayer();

  const [selectedPackType, setSelectedPackType] = useState<PackType>('common');
  const [isOpening, setIsOpening] = useState(false);
  const [openedCards, setOpenedCards] = useState<CardType[]>([]);
  const [showResults, setShowResults] = useState(false);

  const PACK_PRICE = PACK_CONFIGS[selectedPackType].price;
  const canAffordPack = coins >= PACK_PRICE;

  const openPack = async () => {
    if (!canAffordPack || isOpening) return;

    if (!spendCoins(PACK_PRICE)) return;

    setIsOpening(true);
    setShowResults(false);

    setTimeout(() => {
      const newCards = generateCardPack(selectedPackType);
      setOpenedCards(newCards);
      addCards(newCards);
      incrementPacksOpened();
      setIsOpening(false);
      setShowResults(true);
    }, 2000);
  };

  const resetPack = () => {
    setOpenedCards([]);
    setShowResults(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-green-900 to-slate-900 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={onBack} className="text-white border-white">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <h1 className="text-4xl font-bold text-white">Card Packs</h1>
          </div>
          <Badge variant="secondary" className="text-lg px-4 py-2">
            {coins} Coins
          </Badge>
        </div>

        {/* Pack Selection Buttons */}
        {!showResults && (
          <div className="mb-6 flex justify-center gap-3 flex-wrap">
            {Object.keys(PACK_CONFIGS).map((pack) => (
              <Button
                key={pack}
                variant={pack === selectedPackType ? 'default' : 'outline'}
                className="capitalize"
                onClick={() => {
                  setSelectedPackType(pack as PackType);
                  resetPack();
                }}
              >
                {pack} Pack
              </Button>
            ))}
          </div>
        )}

        {!showResults ? (
          <div className="flex flex-col items-center">
            {/* Pack Display */}
            <Card
              className={`mb-8 w-80 h-96 ${
                selectedPackType === 'common'
                  ? 'bg-gradient-to-br from-green-600 to-green-800 border-green-400'
                  : selectedPackType === 'rare'
                  ? 'bg-gradient-to-br from-blue-600 to-blue-800 border-blue-400'
                  : selectedPackType === 'epic'
                  ? 'bg-gradient-to-br from-purple-600 to-purple-800 border-purple-400'
                  : selectedPackType === 'legendary'
                  ? 'bg-gradient-to-br from-yellow-600 to-yellow-800 border-yellow-400'
                  : selectedPackType === 'mythic'
                  ? 'bg-gradient-to-br from-pink-600 to-pink-800 border-pink-400'
                  : 'bg-gradient-to-br from-red-800 to-red-900 border-red-700'
              }`}
            >
              <CardHeader className="text-center">
                <CardTitle className="text-white text-2xl capitalize">{selectedPackType} Pack</CardTitle>
                <Badge variant="outline" className="text-white border-white mx-auto w-fit">
                  5 Cards - {PACK_PRICE} Coins
                </Badge>
              </CardHeader>
              <CardContent className="flex flex-col items-center justify-center h-full">
                {isOpening ? (
                  <div className="text-center">
                    <Sparkles className="w-16 h-16 text-yellow-400 mx-auto mb-4 animate-spin" />
                    <p className="text-white text-lg animate-pulse">Opening pack...</p>
                  </div>
                ) : (
                  <Package
                    className={`w-32 h-32 ${
                      selectedPackType === 'common'
                        ? 'text-green-200'
                        : selectedPackType === 'rare'
                        ? 'text-blue-200'
                        : selectedPackType === 'epic'
                        ? 'text-purple-200'
                        : selectedPackType === 'legendary'
                        ? 'text-yellow-200'
                        : selectedPackType === 'mythic'
                        ? 'text-pink-200'
                        : 'text-red-400'
                    }`}
                  />
                )}
              </CardContent>
            </Card>

            {/* Pack Info */}
            <Card className="mb-6 bg-slate-800 border-slate-700 max-w-md">
              <CardHeader>
                <CardTitle className="text-white text-center">Pack Contents</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between text-gray-300">
                  <span>{PACK_CONFIGS[selectedPackType].guaranteedCards.common}× Common Cards</span>
                  <span>Guaranteed</span>
                </div>
                <div className="flex justify-between text-blue-300">
                  <span>{PACK_CONFIGS[selectedPackType].guaranteedCards.rareOrBetter}× Rare or Better</span>
                  <span>Guaranteed</span>
                </div>
                <div className="flex justify-between text-gray-300">
                  <span>{PACK_CONFIGS[selectedPackType].guaranteedCards.random}× Random Card</span>
                  <span>Any Rarity</span>
                </div>
              </CardContent>
            </Card>

            {/* Open Pack Button */}
            <Button
              onClick={openPack}
              disabled={!canAffordPack || isOpening}
              size="lg"
              className="bg-green-600 hover:bg-green-700 text-white text-xl px-8 py-4"
            >
              {isOpening ? (
                <>
                  <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                  Opening...
                </>
              ) : (
                <>
                  <Package className="w-5 h-5 mr-2" />
                  Open Pack ({PACK_PRICE} Coins)
                </>
              )}
            </Button>

            {!canAffordPack && (
              <p className="text-red-400 mt-4 text-center">
                Not enough coins! You need {PACK_PRICE - coins} more coins.
              </p>
            )}
          </div>
        ) : (
          <div>
            {/* Pack Results */}
            <div className="text-center mb-6">
              <h2 className="text-3xl font-bold text-white mb-2">Pack Opened!</h2>
              <p className="text-gray-300">You received {openedCards.length} new cards:</p>
            </div>

            {/* Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
              {openedCards.map((card, index) => (
                <div
                  key={card.id}
                  className="animate-pulse"
                  style={{ animationDelay: `${index * 0.2}s` }}
                >
                  <CardDisplay card={card} size="medium" />
                </div>
              ))}
            </div>

            {/* Rarity Summary */}
            <Card className="mb-6 bg-slate-800 border-slate-700">
              <CardContent className="p-4">
                <div className="flex justify-center gap-4 flex-wrap">
                  {['common', 'rare', 'epic', 'legendary', 'mythic', 'forsaken'].map((rarity) => {
                    const count = openedCards.filter(card => card.rarity === rarity).length;
                    if (count === 0) return null;

                    const colors: Record<string, string> = {
                      common: 'text-gray-300 border-gray-500',
                      rare: 'text-blue-300 border-blue-500',
                      epic: 'text-purple-300 border-purple-500',
                      legendary: 'text-yellow-300 border-yellow-500',
                      mythic: 'text-pink-300 border-pink-500',
                      forsaken: 'text-red-400 border-red-600',
                    };

                    return (
                      <Badge
                        key={rarity}
                        variant="outline"
                        className={colors[rarity]}
                      >
                        {count}× {rarity.charAt(0).toUpperCase() + rarity.slice(1)}
                      </Badge>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <div className="flex justify-center gap-4 flex-wrap">
              <Button
                onClick={resetPack}
                variant="outline"
                className="text-white border-white"
              >
                Open Another Pack
              </Button>
              <Button onClick={onBack}>
                Back to Home
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
