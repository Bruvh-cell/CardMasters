import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { CardDisplay } from './CardDisplay';
import { useBattle } from '@/lib/stores/useBattle';
import { useCards } from '@/lib/stores/useCards';
import { generateRandomCards } from '@/lib/cardData';
import { getRandomMove, getRandomTarget, getRandomAttacker, executeMove, canUseMove, getBaseDamage, getActiveCard } from '@/lib/battleLogic';
import { ArrowLeft, Zap, Heart, Clock, Sword } from 'lucide-react';
import { PlayerCard } from '@/types/card';
import { useRef } from 'react';

interface Battle1v1Props {
  onBack: () => void;
  onBattleEnd: (result: { winner: 'player' | 'enemy'; coinsEarned: number }) => void;
}

export function Battle1v1({ onBack, onBattleEnd }: Battle1v1Props) {
  const { decks } = useCards();
  const {
    phase,
    playerCards,
    enemyCards,
    activePlayerCardIndex,
    activeEnemyCardIndex,
    currentTurn,
    turnCount,
    winner,
    battleLog,
    initBattle,
    executeAction,
    switchActiveCard,
    endTurn,
    endBattle,
    addLogEntry
  } = useBattle();

  const [selectedPlayerCard, setSelectedPlayerCard] = useState<PlayerCard | null>(null);
  const [selectedMove, setSelectedMove] = useState<'move1' | 'move2' | 'move3' | 'ace' | null>(null);
  const [autoPlay, setAutoPlay] = useState(false);
  const prevEnemyHpRef = useRef<number | null>(null);


  // Initialize battle
  // Initialize battle
  useEffect(() => {
    if (phase === 'setup') {
      const playerDeck = decks['1v1'];
      if (playerDeck.length === 0) {
        addLogEntry("No cards in 1v1 deck! Please set up your deck first.");
        return;
      }

      // Use all cards in the player's deck for the battle
      const playerBattleCards = playerDeck.map(card => ({
        ...card,
        currentHp: card.hp,
        currentMana: card.mana
      }));

      // Generate 5 enemy cards
      const enemyDeck = generateRandomCards(5, false);
      const enemyBattleCards = enemyDeck.map(card => ({
        ...card,
        currentHp: card.hp,
        currentMana: card.mana
      }));

      initBattle('1v1', playerBattleCards, enemyBattleCards);
    }
  }, [phase, decks, initBattle, addLogEntry]);



  // Automatically switch enemy active card if current dies
  useEffect(() => {
    if (phase === 'active') {
      const currentEnemyCard = enemyCards[activeEnemyCardIndex];
      if (!currentEnemyCard) return;

      const prevHp = prevEnemyHpRef.current;

      // Trigger switch only if previously above 0 and now <= 0 (card just died)
      if (prevHp !== null && prevHp > 0 && currentEnemyCard.currentHp <= 0) {
        // Find next alive enemy card index
        const nextAliveIndex = enemyCards.findIndex(
          (card, idx) => card.currentHp > 0 && idx !== activeEnemyCardIndex
        );

        if (nextAliveIndex !== -1) {
          switchActiveCard('enemy', nextAliveIndex);
          addLogEntry(`Enemy switched to ${enemyCards[nextAliveIndex].name}!`);
        }
      }

      prevEnemyHpRef.current = currentEnemyCard.currentHp;
    }
  }, [enemyCards, activeEnemyCardIndex, phase, switchActiveCard, addLogEntry]);


  // Handle enemy turn
  useEffect(() => {
    if (currentTurn === 'enemy' && phase === 'active') {
      const timer = setTimeout(() => {
        // Active enemy card attacks active player card
        const attacker = getActiveCard(enemyCards, activeEnemyCardIndex);
        const target = getActiveCard(playerCards, activePlayerCardIndex);

        if (attacker && target) {
          const moveType = getRandomMove(attacker);
          if (moveType) {
            const action = executeMove(attacker, target, moveType);
            executeAction(action);
          }
        }

        setTimeout(() => {
          endTurn();
        }, 1000);
      }, 2000);

      return () => clearTimeout(timer);
    }
  }, [currentTurn, phase, enemyCards, playerCards, activeEnemyCardIndex, activePlayerCardIndex, executeAction, endTurn]);

  // Handle battle end
  useEffect(() => {
    if (phase === 'ended' && winner) {
      const result = endBattle(winner);
      setTimeout(() => {
        onBattleEnd(result);
      }, 2000);
    }
  }, [phase, winner, endBattle, onBattleEnd]);

  const handlePlayerMove = () => {
    if (!selectedMove || currentTurn !== 'player') return;

    const attacker = getActiveCard(playerCards, activePlayerCardIndex);
    const target = getActiveCard(enemyCards, activeEnemyCardIndex);

    if (!attacker || !target) return;

    if (!canUseMove(attacker, selectedMove)) {
      addLogEntry(`${attacker.name} cannot use ${selectedMove}!`);
      return;
    }

    const action = executeMove(attacker, target, selectedMove);
    executeAction(action);

    setSelectedMove(null);

    setTimeout(() => {
      endTurn();
    }, 1000);
  };

  const alivePlayerCards = playerCards.filter(card => card.currentHp > 0);
  const aliveEnemyCards = enemyCards.filter(card => card.currentHp > 0);

  if (phase === 'setup') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-red-900 to-slate-900 flex items-center justify-center">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-8">
            <p className="text-white text-lg">Setting up 1v1 battle...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-red-900 to-slate-900 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={onBack} className="text-white border-white">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <h1 className="text-3xl font-bold text-white">1v1 Battle</h1>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="secondary" className="text-lg px-4 py-2">
              <Clock className="w-4 h-4 mr-2" />
              Turn {turnCount}
            </Badge>
            <Badge 
              variant={currentTurn === 'player' ? 'default' : 'secondary'}
              className="text-lg px-4 py-2"
            >
              {currentTurn === 'player' ? 'Your Turn' : 'Enemy Turn'}
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Player Side */}
          <div className="lg:col-span-1">
            <Card className="bg-blue-900 border-blue-700">
              <CardHeader>
                <CardTitle className="text-white">Your Cards</CardTitle>
              </CardHeader>
              <CardContent>
                {alivePlayerCards.length > 0 ? (
                  <div className="space-y-4">
                    {/* Active Card */}
                    {playerCards[activePlayerCardIndex] && playerCards[activePlayerCardIndex].currentHp > 0 && (
                      <div className="border-2 border-yellow-400 rounded-lg p-2 bg-yellow-50/10">
                        <div className="text-xs text-yellow-400 font-bold mb-1">⚡ ACTIVE</div>
                        <div className="text-white">
                          <h3 className="font-bold">{playerCards[activePlayerCardIndex].name}</h3>
                          <div className="flex justify-between items-center mt-2">
                            <div className="flex items-center gap-1">
                              <Heart className="w-4 h-4 text-red-400" />
                              <span>{playerCards[activePlayerCardIndex].currentHp}/{playerCards[activePlayerCardIndex].hp}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Zap className="w-4 h-4 text-blue-400" />
                              <span>{playerCards[activePlayerCardIndex].currentMana}/{playerCards[activePlayerCardIndex].mana}</span>
                            </div>
                          </div>
                          <div className="mt-2 space-y-1">
                            <Progress value={(playerCards[activePlayerCardIndex].currentHp / playerCards[activePlayerCardIndex].hp) * 100} className="h-2" />
                            <Progress value={(playerCards[activePlayerCardIndex].currentMana / playerCards[activePlayerCardIndex].mana) * 100} className="h-2 bg-blue-200" />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Other Cards */}
                    {alivePlayerCards.length > 1 && (
                      <>
                        <div className="text-xs text-gray-400 font-bold mb-2">🔄 SWITCH TO:</div>
                        {playerCards.map((card, index) => (
                          index !== activePlayerCardIndex && card.currentHp > 0 && (
                            <div 
                              key={card.id}
                              className="p-3 border-2 rounded cursor-pointer transition-all opacity-70 hover:opacity-100 border-blue-600 hover:border-blue-500"
                              onClick={() => currentTurn === 'player' && switchActiveCard('player', index)}
                            >
                              <div className="text-white">
                                <h3 className="font-bold">{card.name}</h3>
                                <div className="flex justify-between items-center mt-2">
                                  <div className="flex items-center gap-1">
                                    <Heart className="w-4 h-4 text-red-400" />
                                    <span>{card.currentHp}/{card.hp}</span>
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <Zap className="w-4 h-4 text-blue-400" />
                                    <span>{card.currentMana}/{card.mana}</span>
                                  </div>
                                </div>
                                <div className="mt-2 space-y-1">
                                  <Progress value={(card.currentHp / card.hp) * 100} className="h-2" />
                                  <Progress value={(card.currentMana / card.mana) * 100} className="h-2 bg-blue-200" />
                                </div>
                              </div>
                            </div>
                          )
                        ))}
                      </>
                    )}
                  </div>
                ) : (
                  <p className="text-red-400">All your cards are defeated!</p>
                )}
              </CardContent>
            </Card>

            {/* Move Selection */}
            {playerCards[activePlayerCardIndex] && currentTurn === 'player' && (
              <Card className="mt-4 bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Select Move</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {[
                    { type: 'move1' as const, name: playerCards[activePlayerCardIndex].move1, cost: playerCards[activePlayerCardIndex].cost1, damage: getBaseDamage('move1') },
                    { type: 'move2' as const, name: playerCards[activePlayerCardIndex].move2, cost: playerCards[activePlayerCardIndex].cost2, damage: getBaseDamage('move2') },
                    { type: 'move3' as const, name: playerCards[activePlayerCardIndex].move3, cost: playerCards[activePlayerCardIndex].cost3, damage: getBaseDamage('move3') },
                    { type: 'ace' as const, name: playerCards[activePlayerCardIndex].ace, cost: Math.floor(playerCards[activePlayerCardIndex].mana * 0.8), damage: getBaseDamage('ace') }
                  ].map(move => (
                    <Button
                      key={move.type}
                      variant={selectedMove === move.type ? "default" : "outline"}
                      className={`w-full justify-between text-left ${
                        !canUseMove(playerCards[activePlayerCardIndex], move.type) 
                          ? 'opacity-50 cursor-not-allowed' 
                          : ''
                      }`}
                      onClick={() => setSelectedMove(move.type)}
                      disabled={!canUseMove(playerCards[activePlayerCardIndex], move.type)}
                    >
                      <span>{move.name}</span>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <Sword className="w-3 h-3 text-red-400" />
                          <Badge variant="destructive" className="text-white border-red-600 bg-red-600">
                            {move.damage}
                          </Badge>
                        </div>

                        <div className="flex items-center gap-1">
                          <Zap className={`w-3 h-3 ${
                            playerCards[activePlayerCardIndex].currentMana >= move.cost 
                              ? 'text-blue-400' 
                              : 'text-red-400'
                          }`} />
                          <Badge variant={
                            playerCards[activePlayerCardIndex].currentMana >= move.cost 
                              ? "secondary" 
                              : "destructive"
                          }>
                            {move.cost}
                          </Badge>
                        </div>
                      </div>
                    </Button>
                  ))}

                  <Button
                    onClick={handlePlayerMove}
                    disabled={!selectedMove}
                    className="w-full mt-4 bg-green-600 hover:bg-green-700"
                  >
                    Execute Move
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Battle Arena */}
          <div className="lg:col-span-2">
            <Card className="bg-slate-800 border-slate-700 h-96">
              <CardHeader>
                <CardTitle className="text-white text-center">Battle Arena</CardTitle>
              </CardHeader>
              <CardContent className="h-full flex items-center justify-center">
                {phase === 'ended' ? (
                  <div className="text-center">
                    <h2 className={`text-4xl font-bold mb-4 ${
                      winner === 'player' ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {winner === 'player' ? 'Victory!' : 'Defeat!'}
                    </h2>
                    <p className="text-white text-lg">
                      {winner === 'player' ? 'You won the battle!' : 'Better luck next time!'}
                    </p>
                  </div>
                ) : (
                  <div className="w-full flex justify-between items-center">
                    {/* Player Active Card Preview */}
                    <div className="text-center">
                      {playerCards[activePlayerCardIndex] && (
                        <div>
                          <div className="text-xs text-yellow-400 font-bold mb-2">⚡ YOUR ACTIVE CARD</div>
                          <CardDisplay 
                            card={playerCards[activePlayerCardIndex]} 
                            showCurrentStats 
                            currentHp={playerCards[activePlayerCardIndex].currentHp}
                            currentMana={playerCards[activePlayerCardIndex].currentMana}
                            size="medium"
                          />
                        </div>
                      )}
                    </div>

                    <div className="text-center">
                      <p className="text-white text-2xl font-bold">VS</p>
                    </div>

                    {/* Enemy Active Card Preview */}
                    <div className="text-center">
                      {enemyCards[activeEnemyCardIndex] && (
                        <div>
                          <div className="text-xs text-red-400 font-bold mb-2">⚡ ENEMY ACTIVE CARD</div>
                          <CardDisplay 
                            card={enemyCards[activeEnemyCardIndex]} 
                            showCurrentStats 
                            currentHp={enemyCards[activeEnemyCardIndex].currentHp}
                            currentMana={enemyCards[activeEnemyCardIndex].currentMana}
                            size="medium"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Enemy Side */}
          <div className="lg:col-span-1">
            <Card className="bg-red-900 border-red-700">
              <CardHeader>
                <CardTitle className="text-white">Enemy Cards</CardTitle>
              </CardHeader>
              <CardContent>
                {enemyCards.length > 0 ? (
                  <div className="space-y-4">
                    {enemyCards.map((card, index) => (
                      <div 
                        key={card.id} 
                        className={`p-3 border-2 rounded ${
                          index === activeEnemyCardIndex 
                            ? 'border-yellow-400 bg-yellow-50/10' 
                            : 'border-red-600'
                        }`}
                      >
                        <div className="text-white">
                          <h3 className="font-bold">{card.name}</h3>
                          <div className="flex justify-between items-center mt-2">
                            <div className="flex items-center gap-1">
                              <Heart className="w-4 h-4 text-red-400" />
                              <span>{card.currentHp}/{card.hp}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Zap className="w-4 h-4 text-blue-400" />
                              <span>{card.currentMana}/{card.mana}</span>
                            </div>
                          </div>
                          <div className="mt-2 space-y-1">
                            <Progress value={(card.currentHp / card.hp) * 100} className="h-2" />
                            <Progress value={(card.currentMana / card.mana) * 100} className="h-2 bg-blue-200" />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-green-400">All enemy cards are defeated!</p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Battle Log */}
        <Card className="mt-6 max-h-64 overflow-y-auto bg-slate-900 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Battle Log</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-1 text-sm text-gray-300">
              {battleLog.map((entry, idx) => (
                <li key={idx}>{entry}</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
