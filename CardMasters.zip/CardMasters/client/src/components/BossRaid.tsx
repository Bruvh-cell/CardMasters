import { Button } from '@/components/ui/button';

interface BossRaidProps {
  onBack: () => void;
  onNavigate: (screen: string) => void;
}


export function BossRaid({ onBack, onNavigate }: BossRaidProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-red-800 via-yellow-700 to-red-900 p-4 flex flex-col items-center justify-center text-white">
      <h1 className="text-5xl font-bold mb-6">Boss Raids</h1>
      <p className="mb-6 text-lg max-w-lg text-center">
        Prepare for epic 5v1 battles against powerful bosses! This feature is coming soon.
      </p>
      
      <Button onClick={() => onNavigate('battle-boss')} variant="outline" className="bg-gradient-to-br from-red-600 to-yellow-800 border-white-400 hover:scale-105 transition-transform cursor-pointer mb-3">
        Enter the raid
      </Button>
      
      <Button onClick={onBack} variant="outline" className="text-white border-white">
        Back to Home
      </Button>
      
    </div>
  );
}
