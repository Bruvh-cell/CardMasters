import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CardDisplay } from './CardDisplay';
import { useCards } from '@/lib/stores/useCards';
import { ArrowLeft, Search, Filter } from 'lucide-react';

interface InventoryProps {
  onBack: () => void;
}

export function Inventory({ onBack }: InventoryProps) {
  const { collection, removeCard } = useCards();
  const [searchTerm, setSearchTerm] = useState('');
  const [rarityFilter, setRarityFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('name');

  // Defensive check to ensure collection is an array
  const safeCollection = Array.isArray(collection) ? collection : [];

  // Filter and sort cards
  const filteredCards = safeCollection
    .filter(card => {
      const matchesSearch = card.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesRarity = rarityFilter === 'all' || card.rarity === rarityFilter;
      return matchesSearch && matchesRarity;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'hp':
          return b.hp - a.hp;
        case 'mana':
          return b.mana - a.mana;
        case 'speed':
          return b.speed - a.speed;
        case 'rarity':
          const rarityOrder = { common: 0, rare: 1, epic: 2, legendary: 3, mythic: 4, forsaken: 5 };
          return rarityOrder[b.rarity] - rarityOrder[a.rarity];
        default:
          return 0;
      }
    });

  const rarityCount = {
    common: safeCollection.filter(c => c.rarity === 'common').length,
    rare: safeCollection.filter(c => c.rarity === 'rare').length,
    epic: safeCollection.filter(c => c.rarity === 'epic').length,
    legendary: safeCollection.filter(c => c.rarity === 'legendary').length,
    mythic: safeCollection.filter(c => c.rarity === 'mythic').length,
    forsaken: safeCollection.filter(c => c.rarity === 'forsaken').length
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={onBack} className="text-white border-white">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <h1 className="text-4xl font-bold text-white">Card Inventory</h1>
          </div>
          <Badge variant="secondary" className="text-lg px-4 py-2">
            {safeCollection.length} Cards
          </Badge>
        </div>

        {/* Collection Stats */}
        <Card className="mb-6 bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Collection Overview</CardTitle>
          </CardHeader>
          <CardContent className="flex gap-4">
            <Badge variant="outline" className="text-gray-300 border-gray-500">
              Common: {rarityCount.common}
            </Badge>
            <Badge variant="outline" className="text-blue-300 border-blue-500">
              Rare: {rarityCount.rare}
            </Badge>
            <Badge variant="outline" className="text-purple-300 border-purple-500">
              Epic: {rarityCount.epic}
            </Badge>
            <Badge variant="outline" className="text-yellow-300 border-yellow-500">
              Legendary: {rarityCount.legendary}
            </Badge>
            <Badge variant="outline" className="text-pink-300 border-pink-500">
              Mythic: {rarityCount.mythic}
            </Badge>
            <Badge variant="outline" className="text-red-400 border-red-600">
              Forsaken: {rarityCount.forsaken}
            </Badge>
          </CardContent>
        </Card>

        {/* Filters */}
        <Card className="mb-6 bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="flex flex-wrap gap-4 items-center">
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search cards..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-64 bg-slate-700 border-slate-600 text-white"
                />
              </div>

              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-400" />
                <Select value={rarityFilter} onValueChange={setRarityFilter}>
                  <SelectTrigger className="w-40 bg-slate-700 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    <SelectItem value="all">All Rarities</SelectItem>
                    <SelectItem value="common">Common</SelectItem>
                    <SelectItem value="rare">Rare</SelectItem>
                    <SelectItem value="epic">Epic</SelectItem>
                    <SelectItem value="legendary">Legendary</SelectItem>
                    <SelectItem value="mythic">Mythic</SelectItem>
                    <SelectItem value="forsaken">Forsaken</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-40 bg-slate-700 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  <SelectItem value="name">Name</SelectItem>
                  <SelectItem value="hp">HP</SelectItem>
                  <SelectItem value="mana">Mana</SelectItem>
                  <SelectItem value="speed">Speed</SelectItem>
                  <SelectItem value="rarity">Rarity</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Cards Grid */}
        {filteredCards.length === 0 ? (
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-8 text-center">
              <p className="text-gray-400 text-lg">No cards found matching your criteria.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {filteredCards.map((card) => (
              <div key={card.id} className="relative">
                <CardDisplay
                  card={card}
                  size="medium"
                />
                <button
                  onClick={() => removeCard(card.id)}
                  className="absolute top-1 right-1 bg-red-600 hover:bg-red-700 text-white rounded px-2 py-1 text-xs z-10"
                  title="Delete card"
                  aria-label={`Delete ${card.name}`}
                >
                  Delete
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
