import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { usePlayer } from '@/lib/stores/usePlayer';
import { Coins, Trophy, Target, Package, Settings, Swords } from 'lucide-react';

interface HomeScreenProps {
  onNavigate: (screen: 'home' | 'inventory' | 'card-packs' | 'battle-setup' | 'mode-select' | 'battle-1v1' | 'battle-3v3' | 'battle-result'| 'boss-raids') => void;
}

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  const { coins, wins, losses } = usePlayer();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-6xl font-bold text-white mb-4 drop-shadow-lg">
            Card Battle Arena
          </h1>
          <div className="flex justify-center gap-6 text-lg">
            <Badge variant="secondary" className="px-4 py-2 text-lg">
              <Coins className="w-5 h-5 mr-2" />
              {coins} Coins
            </Badge>
            <Badge variant="secondary" className="px-4 py-2 text-lg">
              <Trophy className="w-5 h-5 mr-2" />
              {wins}W - {losses}L
            </Badge>
          </div>
        </div>

        {/* Main Menu Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Battle Modes */}
          <Card className="bg-gradient-to-br from-red-600 to-red-800 border-red-400 hover:scale-105 transition-transform cursor-pointer"
                onClick={() => onNavigate('mode-select')}>
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Swords className="w-6 h-6 mr-2" />
                Battle Modes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-red-100 mb-4">Challenge opponents in 1v1 or 3v3 battles!</p>
              <div className="flex gap-2">
                <Badge variant="outline" className="text-white border-white">1v1</Badge>
                <Badge variant="outline" className="text-white border-white">3v3</Badge>
              </div>
            </CardContent>
          </Card>

          {/* Inventory */}
          <Card className="bg-gradient-to-br from-blue-600 to-blue-800 border-blue-400 hover:scale-105 transition-transform cursor-pointer"
                onClick={() => onNavigate('inventory')}>
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Package className="w-6 h-6 mr-2" />
                Inventory
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-blue-100">View and manage your card collection</p>
            </CardContent>
          </Card>

          {/* Card Packs */}
          <Card className="bg-gradient-to-br from-green-600 to-green-800 border-green-400 hover:scale-105 transition-transform cursor-pointer"
                onClick={() => onNavigate('card-packs')}>
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Package className="w-6 h-6 mr-2" />
                Card Packs
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-green-100 mb-2">Open packs to get new cards!</p>
            </CardContent>
          </Card>

          {/* Battle Setup */}
          <Card className="bg-gradient-to-br from-purple-600 to-purple-800 border-purple-400 hover:scale-105 transition-transform cursor-pointer"
                onClick={() => onNavigate('battle-setup')}>
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Settings className="w-6 h-6 mr-2" />
                Battle Setup
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-purple-100">Configure your decks for battle</p>
            </CardContent>
          </Card>

          {/* Stats Card */}
          <Card className="bg-gradient-to-br from-yellow-600 to-yellow-800 border-yellow-400">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Trophy className="w-6 h-6 mr-2" />
                Statistics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-yellow-100">
                <div className="flex justify-between">
                  <span>Wins:</span>
                  <span className="font-bold">{wins}</span>
                </div>
                <div className="flex justify-between">
                  <span>Losses:</span>
                  <span className="font-bold">{losses}</span>
                </div>
                <div className="flex justify-between">
                  <span>Win Rate:</span>
                  <span className="font-bold">
                    {wins + losses > 0 ? Math.round((wins / (wins + losses)) * 100) : 0}%
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Boss Raids */}
          <Card 
            className="bg-gradient-to-br from-red-700 via-yellow-600 to-red-800 border-yellow-400 hover:scale-105 transition-transform cursor-pointer"
            onClick={() => onNavigate('boss-raids')}
          >
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Target className="w-6 h-6 mr-2" />
                Boss Raids
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-yellow-100 mb-2">5v1 battles against powerful bosses</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
