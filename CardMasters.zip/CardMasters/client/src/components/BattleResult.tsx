import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { usePlayer } from '@/lib/stores/usePlayer';
import { useBattle } from '@/lib/stores/useBattle';
import { Trophy, Coins, Target, RotateCcw, Home } from 'lucide-react';
import { useEffect } from 'react';

interface BattleResultProps {
  result: {
    winner: 'player' | 'enemy';
    coinsEarned: number;
  };
  onPlayAgain: () => void;
  onHome: () => void;
}

export function BattleResult({ result, onPlayAgain, onHome }: BattleResultProps) {
  const { addCoins, addWin, addLoss } = usePlayer();
  const { resetBattle } = useBattle();

  useEffect(() => {
    // Award coins and update stats
    addCoins(result.coinsEarned);
    if (result.winner === 'player') {
      addWin();
    } else {
      addLoss();
    }
  }, [result, addCoins, addWin, addLoss]);

  const handlePlayAgain = () => {
    resetBattle();
    onPlayAgain();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4">
      <Card className={`w-full max-w-2xl ${
        result.winner === 'player' 
          ? 'bg-gradient-to-br from-green-800 to-green-900 border-green-600' 
          : 'bg-gradient-to-br from-red-800 to-red-900 border-red-600'
      }`}>
        <CardHeader className="text-center">
          <div className={`text-8xl mb-4 ${
            result.winner === 'player' ? 'text-green-400' : 'text-red-400'
          }`}>
            {result.winner === 'player' ? '🏆' : '💀'}
          </div>
          <CardTitle className={`text-4xl font-bold ${
            result.winner === 'player' ? 'text-green-100' : 'text-red-100'
          }`}>
            {result.winner === 'player' ? 'VICTORY!' : 'DEFEAT!'}
          </CardTitle>
          <p className={`text-xl mt-2 ${
            result.winner === 'player' ? 'text-green-200' : 'text-red-200'
          }`}>
            {result.winner === 'player' 
              ? 'Congratulations! You won the battle!'
              : 'Better luck next time! Keep training!'
            }
          </p>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Rewards */}
          <div className="text-center">
            <h3 className={`text-2xl font-bold mb-4 ${
              result.winner === 'player' ? 'text-green-100' : 'text-red-100'
            }`}>
              Battle Rewards
            </h3>
            
            <div className="flex justify-center">
              <Badge 
                variant="outline" 
                className={`text-xl px-6 py-3 ${
                  result.winner === 'player' 
                    ? 'text-yellow-300 border-yellow-500 bg-yellow-500 bg-opacity-20' 
                    : 'text-gray-300 border-gray-500 bg-gray-500 bg-opacity-20'
                }`}
              >
                <Coins className="w-6 h-6 mr-2" />
                +{result.coinsEarned} Coins
              </Badge>
            </div>

            {result.winner === 'player' && (
              <p className="text-green-200 mt-2 text-sm">
                Victory bonus! Use these coins to buy more card packs!
              </p>
            )}
            
            {result.winner === 'enemy' && (
              <p className="text-red-200 mt-2 text-sm">
                Participation reward. Every battle makes you stronger!
              </p>
            )}
          </div>

          {/* Battle Stats */}
          <div className={`grid grid-cols-2 gap-4 p-4 rounded-lg ${
            result.winner === 'player' 
              ? 'bg-green-900 bg-opacity-50' 
              : 'bg-red-900 bg-opacity-50'
          }`}>
            <div className="text-center">
              <Trophy className={`w-8 h-8 mx-auto mb-2 ${
                result.winner === 'player' ? 'text-green-400' : 'text-red-400'
              }`} />
              <p className={`font-bold ${
                result.winner === 'player' ? 'text-green-100' : 'text-red-100'
              }`}>
                Result
              </p>
              <p className={`text-sm ${
                result.winner === 'player' ? 'text-green-200' : 'text-red-200'
              }`}>
                {result.winner === 'player' ? 'Win' : 'Loss'}
              </p>
            </div>
            
            <div className="text-center">
              <Coins className={`w-8 h-8 mx-auto mb-2 ${
                result.winner === 'player' ? 'text-green-400' : 'text-red-400'
              }`} />
              <p className={`font-bold ${
                result.winner === 'player' ? 'text-green-100' : 'text-red-100'
              }`}>
                Coins Earned
              </p>
              <p className={`text-sm ${
                result.winner === 'player' ? 'text-green-200' : 'text-red-200'
              }`}>
                {result.coinsEarned}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 justify-center">
            <Button
              onClick={handlePlayAgain}
              className={`px-8 py-3 text-lg ${
                result.winner === 'player'
                  ? 'bg-green-600 hover:bg-green-700 text-white'
                  : 'bg-red-600 hover:bg-red-700 text-white'
              }`}
            >
              <RotateCcw className="w-5 h-5 mr-2" />
              Play Again
            </Button>
            
            <Button
              onClick={onHome}
              variant="outline"
              className={`px-8 py-3 text-lg ${
                result.winner === 'player'
                  ? 'text-green-100 border-green-400 hover:bg-green-800'
                  : 'text-red-100 border-red-400 hover:bg-red-800'
              }`}
            >
              <Home className="w-5 h-5 mr-2" />
              Home
            </Button>
          </div>

          {/* Tips */}
          <div className={`text-center text-sm p-3 rounded ${
            result.winner === 'player' 
              ? 'bg-green-900 bg-opacity-30 text-green-200' 
              : 'bg-red-900 bg-opacity-30 text-red-200'
          }`}>
            {result.winner === 'player' ? (
              <>
                <p className="font-bold mb-1">💡 Victory Tips:</p>
                <p>Keep building strong decks and try the 3v3 mode for bigger rewards!</p>
              </>
            ) : (
              <>
                <p className="font-bold mb-1">💡 Training Tips:</p>
                <p>Open more card packs, build better decks, and learn your cards' abilities!</p>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
