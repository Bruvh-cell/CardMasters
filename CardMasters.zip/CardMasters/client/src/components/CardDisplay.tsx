import { Card as CardType } from '@/types/card';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Zap, Heart, Wand2, Star } from 'lucide-react';

interface CardDisplayProps {
  card: CardType;
  showCurrentStats?: boolean;
  currentHp?: number;
  currentMana?: number;
  size?: 'small' | 'medium' | 'large';
  onClick?: () => void;
  selected?: boolean;
}

export function CardDisplay({ 
  card, 
  showCurrentStats = false, 
  currentHp, 
  currentMana, 
  size = 'medium',
  onClick,
  selected = false
}: CardDisplayProps) {
  const sizeClasses = {
    small: 'w-32 h-44',
    medium: 'w-48 h-64',
    large: 'w-64 h-80'
  };

  const rarityColors = {
    common: 'border-gray-400 bg-gradient-to-br from-gray-50 to-gray-100',
    rare: 'border-blue-400 bg-gradient-to-br from-blue-50 to-blue-100',
    epic: 'border-purple-400 bg-gradient-to-br from-purple-50 to-purple-100',
    legendary: 'border-yellow-400 bg-gradient-to-br from-yellow-50 to-yellow-100',
    mythic: 'border-pink-500 bg-gradient-to-br from-pink-100 to-pink-200',
    forsaken: 'border-red-600 bg-gradient-to-br from-red-900 to-red-800'
  };

  const rarityTextColors = {
    common: 'text-gray-800',
    rare: 'text-blue-800',
    epic: 'text-purple-800',
    legendary: 'text-yellow-800',
    mythic: 'text-pink-300',
    forsaken: 'text-red-400'
    
  };

  const displayHp = showCurrentStats && currentHp !== undefined ? currentHp : card.hp;
  const displayMana = showCurrentStats && currentMana !== undefined ? currentMana : card.mana;

  return (
    <Card 
      className={`${sizeClasses[size]} ${rarityColors[card.rarity]} ${rarityTextColors[card.rarity]} 
                  hover:scale-105 transition-all duration-200 cursor-pointer border-2
                  ${selected ? 'ring-4 ring-blue-400 ring-opacity-60' : ''}
                  ${onClick ? 'hover:shadow-lg' : ''}`}
      onClick={onClick}
    >
      <CardHeader className="p-3">
        <div className="flex justify-between items-start">
          <CardTitle className={`text-sm font-bold ${rarityTextColors[card.rarity]}`}>
            {card.name}
          </CardTitle>
          <Badge variant="outline" className={`text-xs ${rarityTextColors[card.rarity]}`}>
            {card.rarity}
          </Badge>
        </div>
        
        {/* HP and Mana */}
        <div className="flex justify-between items-center mt-2">
          <div className="flex items-center gap-1">
            <Heart className="w-4 h-4 text-red-500" />
            <span className="text-sm font-bold">{displayHp}</span>
            {showCurrentStats && currentHp !== card.hp && (
              <span className="text-xs text-gray-500">/{card.hp}</span>
            )}
          </div>
          <div className="flex items-center gap-1">
            <Zap className="w-4 h-4 text-blue-500" />
            <span className="text-sm font-bold">{displayMana}</span>
            {showCurrentStats && currentMana !== card.mana && (
              <span className="text-xs text-gray-500">/{card.mana}</span>
            )}
          </div>
        </div>

        {/* Health/Mana bars for battle */}
        {showCurrentStats && (
          <div className="space-y-1 mt-2">
            <Progress value={(displayHp / card.hp) * 100} className="h-2 bg-red-100" />
            <Progress value={(displayMana / card.mana) * 100} className="h-2 bg-blue-100" />
          </div>
        )}
      </CardHeader>

      <CardContent className="p-3 pt-0 space-y-2">
        {/* Moves */}
        <div className="space-y-1">
          <div className="flex justify-between items-center text-xs">
            <span className="truncate">{card.move1}</span>
            <Badge variant="outline" className="text-xs px-1">{card.cost1}</Badge>
          </div>
          <div className="flex justify-between items-center text-xs">
            <span className="truncate">{card.move2}</span>
            <Badge variant="outline" className="text-xs px-1">{card.cost2}</Badge>
          </div>
          <div className="flex justify-between items-center text-xs">
            <span className="truncate">{card.move3}</span>
            <Badge variant="outline" className="text-xs px-1">{card.cost3}</Badge>
          </div>
        </div>

        {/* Ace and Speed */}
        <div className="border-t pt-2 space-y-1">
          <div className="flex items-center gap-1 text-xs">
            <Star className="w-3 h-3 text-yellow-500" />
            <span className="truncate font-medium">{card.ace}</span>
          </div>
          <div className="flex items-center gap-1 text-xs">
            <Wand2 className="w-3 h-3 text-green-500" />
            <span>Speed: {card.speed}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
