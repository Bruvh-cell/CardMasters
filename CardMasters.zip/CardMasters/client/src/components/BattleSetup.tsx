import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CardDisplay } from './CardDisplay';
import { useCards } from '@/lib/stores/useCards';
import { ArrowLeft, Plus, Minus, RotateCcw } from 'lucide-react';
import { Card as CardType } from '@/types/card';

interface BattleSetupProps {
  onBack: () => void;
}

export function BattleSetup({ onBack }: BattleSetupProps) {
  const { collection, decks, addToDeck, removeFromDeck, clearDeck } = useCards();
  const [selectedMode, setSelectedMode] = useState<'1v1' | '3v3'>('1v1');
  const [selectedCard, setSelectedCard] = useState<CardType | null>(null);

  const currentDeck = decks[selectedMode];
  const maxDeckSize = selectedMode === '1v1' ? 5 : 7;
  const availableCards = Array.isArray(collection)
  ? collection.filter(card => !currentDeck.some(deckCard => deckCard.id === card.id))
  : [];


  const handleAddToDeck = (card: CardType) => {
    if (addToDeck(selectedMode, card)) {
      setSelectedCard(null);
    }
  };

  const handleRemoveFromDeck = (cardId: string) => {
    removeFromDeck(selectedMode, cardId);
  };

  const handleClearDeck = () => {
    clearDeck(selectedMode);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={onBack} className="text-white border-white">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <h1 className="text-4xl font-bold text-white">Battle Setup</h1>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Current Deck */}
          <div className="lg:col-span-1">
            <Card className="bg-slate-800 border-slate-700 h-fit">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white">
                    {selectedMode} Deck
                  </CardTitle>
                  <Badge variant="secondary">
                    {currentDeck.length}/{maxDeckSize}
                  </Badge>
                </div>
                <div className="flex gap-2">
                  <Tabs value={selectedMode} onValueChange={(value) => setSelectedMode(value as '1v1' | '3v3')}>
                    <TabsList className="bg-slate-700">
                      <TabsTrigger value="1v1" className="data-[state=active]:bg-slate-600">
                        1v1 (Max 5)
                      </TabsTrigger>
                      <TabsTrigger value="3v3" className="data-[state=active]:bg-slate-600">
                        3v3 (Max 7)
                      </TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Deck Cards */}
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {currentDeck.length === 0 ? (
                    <p className="text-gray-400 text-center py-8">
                      No cards in deck. Add cards from your collection.
                    </p>
                  ) : (
                    currentDeck.map((card) => (
                      <div key={card.id} className="flex items-center gap-2 p-2 bg-slate-700 rounded">
                        <div className="flex-1">
                          <p className="text-white font-medium">{card.name}</p>
                          <div className="flex gap-2 text-sm text-gray-300">
                            <span>HP: {card.hp}</span>
                            <span>Mana: {card.mana}</span>
                            <span>Speed: {card.speed}</span>
                          </div>
                        </div>
                        <Badge variant="outline" className={
                          card.rarity === 'common' ? 'text-gray-300 border-gray-500' :
                          card.rarity === 'rare' ? 'text-blue-300 border-blue-500' :
                          card.rarity === 'epic' ? 'text-purple-300 border-purple-500' :
                          'text-yellow-300 border-yellow-500'
                        }>
                          {card.rarity}
                        </Badge>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleRemoveFromDeck(card.id)}
                        >
                          <Minus className="w-4 h-4" />
                        </Button>
                      </div>
                    ))
                  )}
                </div>

                {/* Deck Actions */}
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={handleClearDeck}
                    disabled={currentDeck.length === 0}
                    className="flex-1"
                  >
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Clear Deck
                  </Button>
                </div>

                {/* Deck Status */}
                <div className="bg-slate-700 p-3 rounded">
                  <p className="text-white text-sm mb-2">Deck Status:</p>
                  {currentDeck.length === 0 && (
                    <p className="text-red-400 text-sm">Empty deck - add cards to battle</p>
                  )}
                  {currentDeck.length > 0 && currentDeck.length < (selectedMode === '1v1' ? 3 : 5) && (
                    <p className="text-yellow-400 text-sm">
                      Deck too small - add {(selectedMode === '1v1' ? 3 : 5) - currentDeck.length} more cards minimum
                    </p>
                  )}
                  {currentDeck.length >= (selectedMode === '1v1' ? 3 : 5) && (
                    <p className="text-green-400 text-sm">Deck ready for battle!</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Card Collection */}
          <div className="lg:col-span-2">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Your Collection</CardTitle>
                <p className="text-gray-400">Click a card to add it to your deck</p>
              </CardHeader>
              <CardContent>
                {availableCards.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-gray-400 text-lg mb-4">
                      {collection.length === 0 
                        ? "No cards in collection. Open card packs to get cards!"
                        : "All cards are already in your deck."
                      }
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    {availableCards.map((card) => (
                      <div key={card.id} className="relative">
                        <CardDisplay
                          card={card}
                          size="small"
                          onClick={() => setSelectedCard(card)}
                          selected={selectedCard?.id === card.id}
                        />
                        {selectedCard?.id === card.id && (
                          <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded">
                            <Button
                              onClick={() => handleAddToDeck(card)}
                              disabled={currentDeck.length >= maxDeckSize}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              <Plus className="w-4 h-4 mr-2" />
                              Add to Deck
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Selected Card Details */}
        {selectedCard && (
          <Card className="mt-6 bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Card Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-6">
                <CardDisplay card={selectedCard} size="medium" />
                <div className="flex-1 space-y-4">
                  <div>
                    <h3 className="text-white text-xl font-bold mb-2">{selectedCard.name}</h3>
                    <Badge variant="outline" className={
                      selectedCard.rarity === 'common' ? 'text-gray-300 border-gray-500' :
                      selectedCard.rarity === 'rare' ? 'text-blue-300 border-blue-500' :
                      selectedCard.rarity === 'epic' ? 'text-purple-300 border-purple-500' :
                      'text-yellow-300 border-yellow-500'
                    }>
                      {selectedCard.rarity}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-white">
                    <div>
                      <p className="text-gray-400">Health Points</p>
                      <p className="text-xl font-bold text-red-400">{selectedCard.hp}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">Mana</p>
                      <p className="text-xl font-bold text-blue-400">{selectedCard.mana}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">Speed</p>
                      <p className="text-xl font-bold text-green-400">{selectedCard.speed}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-white font-bold">Moves:</h4>
                    <div className="space-y-1 text-gray-300">
                      <p>• {selectedCard.move1} (Cost: {selectedCard.cost1})</p>
                      <p>• {selectedCard.move2} (Cost: {selectedCard.cost2})</p>
                      <p>• {selectedCard.move3} (Cost: {selectedCard.cost3})</p>
                      <p>• <span className="text-yellow-400">Ace:</span> {selectedCard.ace}</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
