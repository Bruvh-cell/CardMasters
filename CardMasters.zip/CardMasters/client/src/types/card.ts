export interface Card {
  id: string;
  name: string;
  hp: number;
  mana: number;
  move1: string;
  cost1: number;
  move2: string;
  cost2: number;
  move3: string;
  cost3: number;
  ace: string;
  speed: number;
  rarity: 'common' | 'rare' | 'epic' | 'legendary' | 'mythic' | 'forsaken';
  image?: string;
}

export interface PlayerCard extends Card {
  currentHp: number;
  currentMana: number;
}

export interface Deck {
  id: string;
  name: string;
  cards: Card[];
  maxSize: number;
}
