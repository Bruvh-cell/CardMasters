import { PlayerCard } from './card';

export type BattleMode = '1v1' | '3v3';
export type BattlePhase = 'setup' | 'active' | 'ended';

export interface BattleState {
  mode: BattleMode;
  phase: BattlePhase;
  playerCards: PlayerCard[];
  enemyCards: PlayerCard[];
  activePlayerCardIndex: number;
  activeEnemyCardIndex: number;
  currentTurn: 'player' | 'enemy';
  turnCount: number;
  winner: 'player' | 'enemy' | null;
  battleLog: string[];
}

export interface BattleAction {
  type: 'move1' | 'move2' | 'move3' | 'ace';
  attacker: PlayerCard;
  target: PlayerCard;
  damage: number;
  manaCost: number;
}

export interface BattleResult {
  winner: 'player' | 'enemy';
  coinsEarned: number;
  playerCards: PlayerCard[];
  enemyCards: PlayerCard[];
}
