import { useState, useEffect } from 'react';
import { useCards } from '@/lib/stores/useCards';
import { HomeScreen } from '@/components/HomeScreen';
import { Inventory } from '@/components/Inventory';
import { CardPackOpening } from '@/components/CardPackOpening';
import { BattleSetup } from '@/components/BattleSetup';
import { Battle1v1 } from '@/components/Battle1v1';
import { Battle3v3 } from '@/components/Battle3v3';
import { BossRaid } from '@/components/BossRaid'; 
import { BattleResult } from '@/components/BattleResult';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import '@fontsource/inter';
import { BossMode } from './components/BossMode';

type Screen = 
  | 'home' 
  | 'inventory' 
  | 'card-packs' 
  | 'battle-setup' 
  | 'mode-select'
  | 'battle-1v1' 
  | 'battle-3v3' 
  | 'battle-boss'
  | 'battle-result'
  | 'boss-raids';

interface BattleResult {
  winner: 'player' | 'enemy';
  coinsEarned: number;
}

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [battleResult, setBattleResult] = useState<BattleResult | null>(null);
  const { initializeStarterCards, decks } = useCards();

  // Initialize starter cards on first load
  useEffect(() => {
    initializeStarterCards();
  }, [initializeStarterCards]);

  const handleBattleEnd = (result: BattleResult) => {
    setBattleResult(result);
    setCurrentScreen('battle-result');
  };

  const handlePlayAgain = () => {
    // Go back to the same battle mode
    if (battleResult) {
      // Determine which battle mode to return to based on previous result
      // For now, go to mode select
      setCurrentScreen('mode-select');
    }
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return <HomeScreen onNavigate={(screen) => setCurrentScreen(screen as Screen)} />;
      
      case 'inventory':
        return <Inventory onBack={() => setCurrentScreen('home')} />;
      
      case 'card-packs':
        return <CardPackOpening onBack={() => setCurrentScreen('home')} />;
      
      case 'battle-setup':
        return <BattleSetup onBack={() => setCurrentScreen('home')} />;

      case 'boss-raids':
      return (
        <BossRaid
          onBack={() => setCurrentScreen('home')}
          onNavigate={(screen) => setCurrentScreen(screen as Screen)}
        />
      );

      case 'battle-boss':
      return (
        <BossMode 
          onBack={() => setCurrentScreen('boss-raids')} 
          onBattleEnd={handleBattleEnd}  // <-- Add this line
        />
      );

      
      case 'mode-select':
        return (
          <div className="min-h-screen bg-gradient-to-br from-slate-900 via-red-900 to-slate-900 flex items-center justify-center p-4">
            <Card className="w-full max-w-2xl bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white text-center text-3xl">Select Battle Mode</CardTitle>
                <p className="text-gray-300 text-center">Choose your battle format</p>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* 1v1 Mode */}
                <Card className="bg-gradient-to-r from-blue-600 to-blue-800 border-blue-400 hover:scale-105 transition-transform cursor-pointer"
                      onClick={() => setCurrentScreen('battle-1v1')}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-white text-xl font-bold">1v1 Battle</h3>
                        <p className="text-blue-100">Single card vs single card combat</p>
                        <p className="text-blue-200 text-sm mt-2">
                          Deck requirement: Any cards (1 random card selected)
                        </p>
                        <p className="text-yellow-300 text-sm">Reward: 100 coins (win) / 50 coins (loss)</p>
                      </div>
                      <div className="text-4xl">⚔️</div>
                    </div>
                    <div className="mt-4">
                      <p className="text-blue-100 text-sm">
                        Cards in 1v1 deck: {decks['1v1'].length}/5
                      </p>
                      {decks['1v1'].length === 0 && (
                        <p className="text-red-300 text-sm">⚠️ No cards in 1v1 deck! Set up your deck first.</p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* 3v3 Mode */}
                <Card className="bg-gradient-to-r from-purple-600 to-purple-800 border-purple-400 hover:scale-105 transition-transform cursor-pointer"
                      onClick={() => setCurrentScreen('battle-3v3')}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-white text-xl font-bold">3v3 Battle</h3>
                        <p className="text-purple-100">Three cards vs three cards combat</p>
                        <p className="text-purple-200 text-sm mt-2">
                          Deck requirement: Minimum 3 cards (3 random cards selected)
                        </p>
                        <p className="text-yellow-300 text-sm">Reward: 200 coins (win) / 50 coins (loss)</p>
                      </div>
                      <div className="text-4xl">⚔️⚔️⚔️</div>
                    </div>
                    <div className="mt-4">
                      <p className="text-purple-100 text-sm">
                        Cards in 3v3 deck: {decks['3v3'].length}/7
                      </p>
                      {decks['3v3'].length < 3 && (
                        <p className="text-red-300 text-sm">⚠️ Need at least 3 cards in 3v3 deck! Set up your deck first.</p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Back Button */}
                <div className="flex justify-center">
                  <Button 
                    variant="outline" 
                    onClick={() => setCurrentScreen('home')}
                    className="text-white border-white"
                  >
                    Back to Home
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'battle-1v1':
        return (
          <Battle1v1 
            onBack={() => setCurrentScreen('mode-select')} 
            onBattleEnd={handleBattleEnd}
          />
        );
      
      case 'battle-3v3':
        return (
          <Battle3v3 
            onBack={() => setCurrentScreen('mode-select')} 
            onBattleEnd={handleBattleEnd}
          />
        );
      
      case 'battle-result':
        return battleResult ? (
          <BattleResult 
            result={battleResult}
            onPlayAgain={handlePlayAgain}
            onHome={() => setCurrentScreen('home')}
          />
        ) : null;
      
      default:
        return <HomeScreen onNavigate={(screen) => setCurrentScreen(screen as Screen)} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-900">
      {renderScreen()}
    </div>
  );
}

export default App;
