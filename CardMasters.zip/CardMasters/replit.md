# Card Battle Arena

## Overview

This is a full-stack card battle game built with React/TypeScript on the frontend, Express.js on the backend, and PostgreSQL with Drizzle ORM for data persistence. The application features a comprehensive card collection system, deck building, and turn-based battle mechanics with both 1v1 and 3v3 game modes.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Components**: Radix UI primitives with custom components
- **Styling**: TailwindCSS with custom dark theme configuration
- **State Management**: Zustand for client-side state management
- **Build Tool**: Vite with custom configuration for game assets
- **3D Graphics**: React Three Fiber with Drei and post-processing for visual effects
- **Query Management**: TanStack Query for server state management

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM for schema management
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Development**: TSX for TypeScript execution
- **Architecture Pattern**: RESTful API with `/api` prefix routing

### Key Components

#### Game Systems
1. **Card Collection System**: Players can collect cards through pack opening mechanics
2. **Deck Building**: Separate decks for 1v1 (max 5 cards) and 3v3 (max 7 cards) modes
3. **Battle System**: Turn-based combat with multiple move types and mana management
4. **Player Progress**: Coin economy, win/loss tracking, and pack opening statistics

#### Data Models
- **Users**: Basic user authentication with username/password
- **Cards**: Rich card data with stats, moves, costs, and rarity system
- **Decks**: Player-customizable card collections for different battle modes

#### Battle Mechanics
- **Move Types**: 4 different move types per card (move1, move2, move3, ace)
- **Resource Management**: HP and mana systems with dynamic costs
- **AI Opponents**: Intelligent enemy AI with weighted move selection
- **Battle Results**: Coin rewards and statistics tracking

## Data Flow

1. **Client Application** loads with Zustand stores initializing game state
2. **Card Management** handled through local storage with potential server sync
3. **Battle Logic** runs client-side with deterministic AI opponents
4. **User Data** persists to PostgreSQL via Drizzle ORM
5. **Asset Loading** managed by Vite with support for 3D models and audio files

## External Dependencies

### Frontend Dependencies
- **UI Framework**: Radix UI component library for accessible primitives
- **3D Graphics**: React Three Fiber ecosystem for WebGL rendering
- **State Management**: Zustand for lightweight state management
- **Styling**: TailwindCSS with PostCSS processing
- **Fonts**: Inter font family via Fontsource

### Backend Dependencies
- **Database**: Neon Database serverless PostgreSQL
- **ORM**: Drizzle with zod validation schemas
- **Development Tools**: TSX, esbuild for production builds

### Audio/Visual Assets
- Support for GLTF/GLB 3D models
- Audio file support (MP3, OGG, WAV)
- GLSL shader support for advanced visual effects

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with HMR
- **Backend**: TSX with Express server
- **Database**: Drizzle migrations with push command

### Production
- **Build Process**: Vite builds client to `dist/public`, esbuild bundles server
- **Server**: Node.js with ES modules
- **Database**: Neon Database with connection pooling
- **Assets**: Static file serving through Express

### Environment Configuration
- Database connection via `DATABASE_URL` environment variable
- Separate client/server build outputs
- TypeScript configuration with path mapping for clean imports

## Changelog

```
Changelog:
- June 30, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```